#Les fonction utiles

loss_pred <- function(x, pred, y, type) {
  npred <- length(pred)
  nx <- length(x)
  
  if (npred > 1 && nx > 1) {
    if (type == 1)
      l = matrix(rep((x-y)^2, npred), ncol = npred)
    else if (type == 2)
      l = matrix(rep(abs(x - y), npred), ncol = npred)
    else if (type == 3)
      l = matrix(rep(abs(x - y) / y, npred), ncol = npred)
    else if (type == 4) 
      l = 2 * t(matrix(rep(pred - y, nx), ncol = nx)) * matrix(rep(x, npred), ncol = npred)
    else if (type == 5)
      l = t(matrix(rep(sign(pred - y), nx), ncol = nx)) * matrix(rep(x, npred), ncol = npred)
    else if (type == 6)
      l =  matrix(rep(x, npred), ncol = npred) / y * t(matrix(rep(sign(pred - y), nx), ncol = nx))
  }
  else {
    if (type == 1)
      l = (x-y)^2
    else if (type == 2)
      l = abs(x - y)
    else if (type == 3)
      l = abs(x - y) / y
    else if (type == 4) 
      l = 2 * (pred - y) * x
    else if (type == 5)
      l = sign(pred - y) * x
    else if (type == 6)
      l = x / y * sign(pred - y)
  }
  return(l)
}


rmse <- function(x)
{
  x = as.matrix(x)
  sqrt(apply(x^2,2,mean))
}