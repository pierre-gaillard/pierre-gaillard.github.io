# -----------------------------------------------------------------------------
#            SUITES INDIVIDUELLES SUR DONNÉES SIMULÉES
# -----------------------------------------------------------------------------

rm(list=objects())
path = '~/Documents/Travail/Monitorat/projet-data-mining/'
setwd(path)

# Simulation des données

set.seed(10)
n = 200
time = 1:n
ntrain = floor(n/2);
training = time[1:ntrain]
testing = time[(ntrain+1):n]


w = c(5*runif(1),30*runif(1),100*runif(1))
x = array(0,c(n,3))
x[,1] = cos(2*pi/w[1]*time) + rnorm(n,sd=0.1)
x[,2] = sin(2*pi/w[2]*time) + rnorm(n,sd=0.05)
x[,3] = 2*cos(2*pi/w[3]*time + 1) + rnorm(n,sd=0.3)

lambda = runif(3)
y = x %*% lambda  + rnorm(n,sd=0.2)

matplot(x, type= 'l')
plot(y, type='l')

# On ajoute une variable y avec un délai dans les covariables
y1 = rep(0,n)
y2 = rep(0,n)
y1[2:n] = y[1:(n-1)]
y2[3:n] = y[1:(n-2)]

y = y + 0.2 * y1 + 0.3 * y2

data = data.frame(y = y, x1 = x[,1], x2 = x[,2], x3 = x[,3], y1 = y1, y2=y2)
datatrain = data[1:ntrain,]
datatest = data[(ntrain+1):n,]

# Construction des experts
N = 12
prev = array(0,c(n,N));

# Deux modèles autorégressifs
m1 = ar(datatrain$y, order.max=20)
m2 = ar(datatrain$y, method="burg")

for (t in ntrain:(n-1)) {
  prev[t,1] = predict(m1, y[1:t])$pred[1]
}

for (t in ntrain:(n-1)) {
  prev[t+1,2] = predict(m2, y[1:t])$pred[1];
}

# Des modèles linéaires.
prev[testing,3] = predict(lm(y~x1+x2+x3, datatrain),datatest)
prev[testing,4] = predict(lm(y~x1*x2*x3, datatrain),datatest)
prev[testing,5] = predict(lm(y~x1+x2+x3+y1,datatrain),datatest)

# Du Gam
library("mgcv")
prev[testing,6] = predict(gam(y~x1+x2+x3, data = datatrain),datatest)
prev[testing,7] = predict(gam(y~s(x1)+s(x2)+s(x3), data = datatrain),datatest)
prev[testing,8] = predict(gam(y~x1+x2+x3+y1,data = datatrain),datatest)

# Des random forests
library("randomForest")
prev[testing,9] = predict(randomForest(y~x1+x2+x3, datatrain),datatest)
prev[testing,10] = predict(randomForest(y~x1+x2+x3+y1+y2, datatrain),datatest)

# Des abres de regression
library("tree")
prev[testing,11] = predict(tree(y~x1+x2+x3, datatrain),datatest)
prev[testing,12] = predict(tree(y~x1+x2+x3+y1+y2, datatrain),datatest)

# Quelques mauvais experts
#prev = cbind(prev, rep(0,n))
#prev[testing,15] = rnorm(n-ntrain)
#N=N+2

# Affichage des experts
source('loss-functions.r')
matplot(prev, type='l')
lines(y,col='dark red', lwd=2)

instants = ntrain+1:floor(w[3])
matplot(prev[instants,], type='l')
lines(y[instants],col='dark red', lwd=2)

res = prev - array(rep(y, N), c(n,N));
cat('Erreurs des experts :\n', rmse(res[testing,]), '\n\n')

matplot(res[testing,],type='l')

# --------------------------------
#      Les algos de mélanges
# ---------------------------------
source('algos.r')

w = array(0,c(n,N,4))
w1 <- ewa(1e-1, y[testing], prev[testing,], type=1)
w2 <- ewa(2,y[testing],prev[testing,], type=4)
w3 <- fixed_share(1,0.01,y[testing],prev[testing,], type=1)
w4 <- fixed_share(1,0.01,y[testing],prev[testing,], type=4)

matplot(w1, type='l')
matplot(w2, type='l')

prev1 = array(0,c(n,4))
prev1[testing,1] = apply(w1 * prev[testing,], 1, sum)
prev1[testing,2] = apply(w2 * prev[testing,], 1, sum)
prev1[testing,3] = apply(w3 * prev[testing,], 1, sum)
prev1[testing,4] = apply(w4 * prev[testing,], 1, sum)


res1 = prev1 - array(rep(y, 4), c(n,4));
cat('Erreurs des mélanges : \n', rmse(res1[testing,]))

matplot(prev1[instants,], type='l')
lines(y[instants],col="dark red", lwd=2)
#