

ewa <- function(eta, y, experts, type = 4)
{
  # Nombre d'experts
  N <- ncol(experts)
  T <- nrow(experts)
  R <- rep(0,N)
  w <- matrix(0,ncol=N,nrow=T)
  
  w[1, ] <- rep(1/N,N)
  for(t in 1:(T-1)){
    
    # Prédiction et perte
    pred <- experts[t,] %*% w[t,]    
    lpred <- loss_pred(pred, pred,y[t],type)
    lexp <- loss_pred(experts[t,], pred, y[t], type)
    
    # Mise à jour des regrets et des poids
    R <- R + (lpred - lexp)
    
    w[t+1,] <- t(exp(eta*R))
    w[t+1,] <- w[t+1,] / sum(w[t+1,])
  }
  return(w)
}



fixed_share <- function(eta,alpha,y,experts,type) 
{
  # Nombre d'experts et de pas de temps
  N <- ncol(experts)
  T <- nrow(experts)
  
  # Perte de chaque expert et matrice de poids  
  v <- numeric(N)
  w <- rep(1,N)
  p <- array(0,c(T,N))
  
  # Initialisation
  p[1,] <- rep(1/N,N)
  
  for(t in 1:(T-1)){
    # Prediction et perte
    pred <- experts[t,] %*% p[t,]
    lpred <- loss_pred(pred, pred, y[t], type)
    lexp <- loss_pred(experts[t,], pred, y[t], type)
    
    # Mise à jour du regret
    v <-  w * exp( eta *  (lpred - lexp))
    
    # Mise à jour des poids
    w <- alpha  / N + (1-alpha) * v
    p[t+1,] <- w / sum(w)
  }
  # Renvoi de la matrice de poids 
  return(p)
}